# Reconhecimento do alfabeto manual de Libras — MediaPipe + Python

Projeto didatico de Visao Computacional: a webcam identifica **uma mao**, detecta
**21 pontos** com o MediaPipe, e um **Random Forest** treinado pela equipe
prediz letras **A a Z** a partir da pose e de aproximadamente 1,25 segundo de
movimento. A predicao e feita em tempo real em uma janela deslizante. Pressione
ESPACO para incluir uma letra confirmada no texto.

> **IMPORTANTE:** o projeto e o pipeline de treinamento estao completos, mas
> **nao vem com um modelo de Libras pre-treinado**. Para funcionar com letras,
> e necessario coletar exemplos e executar o treinamento. O modelo `.task`
> baixado automaticamente e o **detector de maos do Google**, nao um
> classificador de Libras. Este prototipo **nao traduz a lingua Libras**:
> reconhece apenas a datilologia (soletracao), com as limitacoes dos dados.

## 1. Ambiente

Recomendamos **Python 3.11 ou 3.12 (64 bits)** e computador com webcam.
No Windows (PowerShell), abra a pasta deste projeto:

```powershell
py -3.11 -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Se nao tiver o Python 3.11 registrado, utilize `python -m venv .venv`.
No macOS/Linux, crie e ative com
`python3 -m venv .venv && source .venv/bin/activate`.

**Atencao:** a webcam e uma janela local OpenCV. A versao comum do Google Colab
nao disponibiliza `cv2.VideoCapture(0)` do seu notebook como se fosse webcam
local. Para esse aplicativo, **rode o Python no proprio computador**.

## 2. Testar webcam e rastreamento

```sh
python principal.py diagnosticar
```

Na primeira vez o programa baixa `modelos/hand_landmarker.task` (modelo oficial
MediaPipe), requerendo internet. Se falhar, use a URL do erro para fazer o
download manual. O teste deve mostrar pontos verdes e vermelhos na sua mao.
Pressione `Q` para sair. Se necessario, use `--camera 1`.

## 3. Coletar exemplos

```sh
python principal.py coletar --letra A --quantidade 30 --pessoa p1
python principal.py coletar --letra B --quantidade 30 --pessoa p1
# ... repetir ate Z
python principal.py coletar --letra J --quantidade 30 --pessoa p1
python principal.py coletar --letra Z --quantidade 30 --pessoa p1
```

A ordem e livre. Ao abrir a janela, coloque a mao em frente da camera,
**pressione ESPACO para iniciar cada gravacao** e mantenha a mao visivel por
**1,25 segundo**. A amostra e salva automaticamente. Pressione ESPACO de novo
para gravar outra amostra, ate completar a quantidade. Para letras com movimento,
**execute o movimento completo durante a gravacao**. Nao segure J/Z paradas.

Recomendacao: comece com **A, B e C** para validar o fluxo. Para o alfabeto
completo, colete **25–50 amostras por letra e por pessoa**, variando iluminacao,
angulo e distancia, respeitando a configuracao correta de cada letra. Envolva
**varias pessoas**: `--pessoa p2`, `--pessoa p3` etc. Use sempre uma unica
mao em quadro; se alternar entre esquerda e direita, aumente muito a coleta.

Os dados ficam em `dados/A/*.npz`, `dados/B/*.npz` etc. Guardamos **apenas os
21 pontos da mao por quadro**, e nao fotos ou videos.

**Letras dinamicas:** J e Z exigem trajetoria; algumas convencoes tambem
atribuem movimento a H, X e outras configuracoes. Consulte um professor ou
instrutor de Libras para validar cada sinal antes de coletar. Este projeto
inclui somente A-Z; a letra adicional `Ç` nao foi implementada.

## 4. Treinar o classificador

```sh
python principal.py treinar
```

E necessario um minimo de **duas letras** e **cinco amostras de cada uma**,
mas isso e apenas para teste tecnico. O treinamento calcula e mostra
acuracia, precision, recall, F1 por letra e salva `dados/matriz_confusao.csv`.
Quando existem varias pessoas, tenta separar pessoas diferentes para teste;
senao, avalia em amostras separadas aleatoriamente e deixa claro que a acuracia
pode ser otimista.

O modelo final, re-treinado com todos os dados, e salvo em:

```
modelos/classificador_libras.joblib
```

## 5. Reconhecer em tempo real

```sh
python principal.py reconhecer
```

**Teclas:**

- `Q` ou `Esc`: sair.
- `Espaco`: adicionar ao texto a letra que aparece como **ESTAVEL**.
- `Backspace`: apagar a ultima letra inserida.
- `C`: limpar o texto.

A inferencia utiliza uma janela deslizante de ~1,25 s e so confirma letras
estaveis. O numero percentual exibido e uma pontuacao interna do Random Forest,
**nao uma probabilidade estatisticamente calibrada**. O limiar `--limite 0.65`
e uma regra heuristica e pode ser ajustado (ex.: `--limite 0.75`).

Nao ha classe "nenhuma das alternativas" nativa: uma configuracao nao vista
pode ser confundida com alguma letra. Para evoluir o prototipo, colete gestos
negativos e inclua logica de rejeicao calibrada. Letras semelhantes e sinais
rapidos exigem mais dados e modelos temporais melhores.

## 6. Estrutura

```
projeto_libras_mediapipe/
|-- principal.py              # Interface CLI, captura, treino e reconhecimento
|-- libras_core.py            # MediaPipe Tasks, desenho, normalizacao, features
|-- requirements.txt          # Dependencias
|-- README.md                 # Este guia
|-- dados/                   # Exemplos .npz por letra, gerados pela equipe
|-- modelos/                 # .task detector e .joblib classificador
|-- testes/                  # Teste automatizado das features
```

## 7. Para apresentacao e avaliacao academica

**Fluxo:** webcam -> OpenCV -> MediaPipe 21 pontos -> normalizacao -> vetor de
caracteristicas da pose/movimento -> Random Forest -> letra prevista -> texto.

**Caracteristicas:** 18 quadros interpolados; 63 coordenadas relativas ao
punho + 2 componentes da trajetoria do punho por quadro, mais 6 estatisticas
das trajetorias das pontas do indicador e minimo. Isso deixa o classificador
menos sensivel a distancia da camera e permite representar movimento.

**Limitacoes:** nao se trata de reconhecimento de Libras em frases, apenas do
alfabeto manual. Exige rotulos corretos e quantidade representativa de dados.
O desempenho do classificador deve ser relatado a partir de testes com pessoas
nao vistas no treinamento, se possivel. Um resultado elevado com amostras muito
parecidas da mesma pessoa nao mede generalizacao de verdade.

## Fontes

- MediaPipe Hand Landmarker (documentacao oficial):
  https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker/python
- Pacote oficial de pontos da mao `.task`:
  https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task
- Alfabeto manual: obtenha revisao de professor(a) de Libras antes de rotular.
