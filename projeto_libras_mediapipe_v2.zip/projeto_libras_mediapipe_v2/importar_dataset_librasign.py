"""Importa amostras ESTATICAS do Kaggle LibraSign para o projeto MediaPipe/Libras.

Fonte externa: https://www.kaggle.com/datasets/heitorccf/librasign
O CSV publica 63 valores por amostra (x,y,z dos 21 landmarks).
Este script NAO cria trajetorias verdadeiras: repete a pose para preencher os 18
quadros exigidos pelo projeto. Serve como baseline APENAS para letras estaticas.
H/J/K/X/Z sao omitidas por cautela, pois o reconhecimento exige movimento
em algumas convencoes e nao pode ser validado com uma pose unica.

Uso no mesmo diretorio que principal.py e libras_core.py:
    python -m pip install kagglehub
    python importar_dataset_librasign.py
    python principal.py treinar

Se baixar ZIP manualmente e descompactar:
    python importar_dataset_librasign.py --pasta-csv 'caminho/para/dados'
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path
import sys
import numpy as np

try:
    from libras_core import PASTA_DADOS, QUADROS
except ImportError as exc:
    raise SystemExit('Coloque este arquivo na mesma pasta de principal.py e libras_core.py') from exc

FONTE = 'heitorccf/librasign'
# O subconjunto conservador com pose estatica permite um primeiro experimento honesto.
LETRAS_ESTATICAS = tuple(x for x in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' if x not in 'HJKXZ')


def localizar_csvs(pasta: Path) -> dict[str, Path]:
    """Encontra arquivos A.csv, B.csv etc. dentro de landmarks/."""
    encontrados = {}
    for caminho in sorted(pasta.rglob('*.csv')):
        if caminho.stem.upper() in LETRAS_ESTATICAS and caminho.stem.upper() not in encontrados:
            encontrados[caminho.stem.upper()] = caminho
    return encontrados


def ler_csv(caminho: Path):
    """Lê CSV sem cabeçalho (ou com cabeçalho) e preserva ordem x,y,z."""
    with caminho.open('r', encoding='utf-8-sig', newline='') as stream:
        leitor = csv.reader(stream)
        for indice, linha in enumerate(leitor):
            if len(linha) < 63:
                continue
            try:
                valores = np.asarray([float(item) for item in linha[:63]], dtype=np.float32)
            except ValueError:
                continue  # pula cabeçalho ou linha inválida
            if not np.isfinite(valores).all():
                continue
            pontos = valores.reshape(21, 3)
            # Normalizações de eixo/escala devem ser consistentes com o webcam.
            if np.linalg.norm(pontos[9, :2] - pontos[0, :2]) < 1e-4:
                continue
            yield indice, pontos


def importar(pasta_csv: Path, max_por_letra: int, substituir: bool) -> dict[str, int]:
    caminhos = localizar_csvs(pasta_csv)
    if not caminhos:
        raise RuntimeError(
            f'Nenhum CSV de letras foi encontrado em {pasta_csv}. '
            'Verifique se os arquivos A.csv, B.csv etc estao dentro da pasta landmarks.'
        )
    resumo = {}
    for letra, caminho in caminhos.items():
        destino = PASTA_DADOS / letra
        destino.mkdir(parents=True, exist_ok=True)
        prefixo = f'librasign_kaggle_{letra}_'
        existentes = sorted(destino.glob(prefixo + '*.npz'))
        if existentes and substituir:
            for arq in existentes:
                arq.unlink()
        elif existentes:
            print(f'[JA IMPORTADA] {letra}: {len(existentes)} arquivos; use --substituir para renovar.')
            resumo[letra] = len(existentes)
            continue
        total = 0
        for idx, pontos in ler_csv(caminho):
            if max_por_letra > 0 and total >= max_por_letra:
                break
            # O projeto original exige 18 quadros por amostra. Aqui temos
            # APENAS uma foto/pose; repetir nao inventa movimento real.
            seq_estatica = np.repeat(pontos[np.newaxis, :, :], QUADROS, axis=0)
            np.savez_compressed(
                destino / f'{prefixo}{idx:06d}.npz',
                frames=seq_estatica,
                letra=np.asarray(letra),
                pessoa=np.asarray('dataset_publico'),
                fonte=np.asarray(FONTE),
                tipo=np.asarray('pose_estatica_repetida'),
            )
            total += 1
        resumo[letra] = total
        print(f'[OK] {letra}: {total} amostras importadas')
    return resumo


def main():
    parser = argparse.ArgumentParser(description='Importa letras estaticas do LibraSign Kaggle para o projeto de Libras.')
    parser.add_argument('--pasta-csv', type=Path, help='Diretorio local onde existem arquivos CSV, caso ja tenha baixado o dataset')
    parser.add_argument('--max-por-letra', type=int, default=150, help='Limite de amostras por classe (0 = todas; padrao: 150)')
    parser.add_argument('--substituir', action='store_true', help='Substitui somente arquivos anteriormente importados pelo script')
    args = parser.parse_args()
    if args.max_por_letra < 0:
        parser.error('--max-por-letra nao pode ser negativo')
    if args.pasta_csv:
        pasta = args.pasta_csv.expanduser().resolve()
    else:
        try:
            import kagglehub
        except ImportError:
            parser.error('Instale o KaggleHub: python -m pip install kagglehub')
        print(f'Baixando dataset publico {FONTE} (requer internet)...')
        pasta = Path(kagglehub.dataset_download(FONTE))
    resumo = importar(pasta, args.max_por_letra, args.substituir)
    if len(resumo) < 2:
        raise RuntimeError('Foram localizadas menos de 2 letras. Confira o dataset.')
    print(f'\nIMPORTACAO CONCLUIDA: {sum(resumo.values())} amostras, {len(resumo)} classes estaticas.')
    print('Execute: python principal.py treinar')
    print('Depois:  python principal.py reconhecer')
    print('ATENCAO: H/J/K/X/Z nao foram incluidas; imagens isoladas nao registram trajetorias.')
    print('Os 18 quadros foram repetidos artificialmente. O desempenho com webcam real precisa ser avaliado.')


if __name__ == '__main__':
    try:
        main()
    except (RuntimeError, OSError) as exc:
        sys.exit(f'ERRO: {exc}')
