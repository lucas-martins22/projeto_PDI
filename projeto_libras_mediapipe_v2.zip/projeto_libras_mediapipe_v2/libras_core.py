"""Nucleo de captura e processamento de gestos para alfabeto manual de Libras.

Utiliza MediaPipe Tasks (API atual), OpenCV e NumPy.
Nao contem nenhum classificador pre-treinado de Libras.
"""
from __future__ import annotations

from pathlib import Path
import time
import urllib.request

import cv2
import numpy as np

BASE = Path(__file__).resolve().parent
PASTA_DADOS = BASE / "dados"
PASTA_MODELOS = BASE / "modelos"
MODELO_MAOS = PASTA_MODELOS / "hand_landmarker.task"
MODELO_LIBRAS = PASTA_MODELOS / "classificador_libras.joblib"
URL_HAND_LANDMARKER = (
    "https://storage.googleapis.com/mediapipe-models/hand_landmarker/"
    "hand_landmarker/float16/1/hand_landmarker.task"
)
LETRAS = tuple("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
QUADROS = 18
DURACAO_AMOSTRA = 1.25  # segundos
VERSAO_FEATURES = 1

# Conexoes padrao entre 21 pontos da mao.
ARESTAS = (
    (0, 1), (1, 2), (2, 3), (3, 4),
    (0, 5), (5, 6), (6, 7), (7, 8),
    (5, 9), (9, 10), (10, 11), (11, 12),
    (9, 13), (13, 14), (14, 15), (15, 16),
    (13, 17), (0, 17), (17, 18), (18, 19), (19, 20),
)


def garantir_modelo_maos() -> Path:
    """Baixa apenas o modelo oficial de deteccao da MAO, se necessario."""
    PASTA_MODELOS.mkdir(parents=True, exist_ok=True)
    if MODELO_MAOS.exists() and MODELO_MAOS.stat().st_size > 100_000:
        return MODELO_MAOS
    temporario = MODELO_MAOS.with_suffix(".download")
    print("Baixando modelo oficial de deteccao de maos do MediaPipe...")
    try:
        urllib.request.urlretrieve(URL_HAND_LANDMARKER, temporario)
        if temporario.stat().st_size < 100_000:
            raise RuntimeError("Arquivo recebido parece incompleto.")
        temporario.replace(MODELO_MAOS)
    except Exception as erro:
        temporario.unlink(missing_ok=True)
        raise RuntimeError(
            "Nao foi possivel baixar o modelo MediaPipe. Conecte-se a internet "
            "ou baixe manualmente o arquivo abaixo e salve em 'modelos/hand_landmarker.task':\n"
            f"{URL_HAND_LANDMARKER}\nDetalhes: {erro}"
        ) from erro
    return MODELO_MAOS


class RastreadorMao:
    """Adaptador MediaPipe Tasks para usar video em ordem cronologica."""

    def __init__(self):
        import mediapipe as mp
        self.mp = mp
        caminho = garantir_modelo_maos()
        opcoes = mp.tasks.vision.HandLandmarkerOptions(
            base_options=mp.tasks.BaseOptions(model_asset_buffer=caminho.read_bytes()),
            running_mode=mp.tasks.vision.RunningMode.VIDEO,
            num_hands=1,
            min_hand_detection_confidence=0.55,
            min_hand_presence_confidence=0.55,
            min_tracking_confidence=0.55,
        )
        self.detector = mp.tasks.vision.HandLandmarker.create_from_options(opcoes)
        self.ultimo_t_ms = -1
        self.ultimo_lado: str | None = None

    def detectar(self, imagem_bgr: np.ndarray) -> np.ndarray | None:
        rgb = cv2.cvtColor(imagem_bgr, cv2.COLOR_BGR2RGB)
        imagem = self.mp.Image(image_format=self.mp.ImageFormat.SRGB, data=np.ascontiguousarray(rgb))
        t_ms = max(int(time.monotonic() * 1000), self.ultimo_t_ms + 1)
        self.ultimo_t_ms = t_ms
        resultado = self.detector.detect_for_video(imagem, t_ms)
        if not resultado.hand_landmarks:
            self.ultimo_lado = None
            return None
        self.ultimo_lado = (
            resultado.handedness[0][0].category_name
            if resultado.handedness and resultado.handedness[0] else None
        )
        # 21 articulacoes; x,y,z normalizados pela dimensao da imagem.
        return np.array(
            [[p.x, p.y, p.z] for p in resultado.hand_landmarks[0]],
            dtype=np.float32,
        )

    def fechar(self) -> None:
        self.detector.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.fechar()


def abrir_camera(indice: int = 0) -> cv2.VideoCapture:
    """Tenta abrir uma webcam; no Windows prioriza DirectShow."""
    import os
    if os.name == "nt":
        camera = cv2.VideoCapture(indice, cv2.CAP_DSHOW)
        if not camera.isOpened():
            camera.release()
            camera = cv2.VideoCapture(indice)
    else:
        camera = cv2.VideoCapture(indice)
    if not camera.isOpened():
        camera.release()
        raise RuntimeError(
            f"Nao foi possivel abrir a camera {indice}. Verifique permissoes e se outro app esta usando a webcam."
        )
    camera.set(cv2.CAP_PROP_FRAME_WIDTH, 960)
    camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 540)
    return camera


def desenhar_mao(imagem: np.ndarray, pontos: np.ndarray | None) -> None:
    if pontos is None:
        return
    altura, largura = imagem.shape[:2]
    coords = [(int(p[0] * largura), int(p[1] * altura)) for p in pontos]
    for a, b in ARESTAS:
        cv2.line(imagem, coords[a], coords[b], (80, 220, 80), 2, cv2.LINE_AA)
    for x, y in coords:
        cv2.circle(imagem, (x, y), 4, (20, 70, 255), -1, cv2.LINE_AA)


def escrever(imagem: np.ndarray, texto: str, y: int, cor=(255, 255, 255),
             tamanho: float = 0.7, x: int = 18) -> None:
    cv2.putText(imagem, texto, (x, y), cv2.FONT_HERSHEY_SIMPLEX, tamanho,
                (0, 0, 0), 4, cv2.LINE_AA)
    cv2.putText(imagem, texto, (x, y), cv2.FONT_HERSHEY_SIMPLEX, tamanho,
                cor, 2, cv2.LINE_AA)


def interpolar_sequencia(pontos: list[np.ndarray], tempos: list[float],
                          quantidade: int = QUADROS) -> np.ndarray:
    """Uniformiza o numero de quadros, mesmo com FPS variavel.

    Recebe apenas quadros com deteccao de uma mao. Para nao apagar movimentos,
    interpola em uma linha temporal igualmente espacada entre inicio e fim do clip.
    """
    if len(pontos) < 5 or len(pontos) != len(tempos):
        raise ValueError("Amostra insuficiente: sao precisos pelo menos 5 quadros detectados.")
    arr = np.asarray(pontos, dtype=np.float32)
    ts = np.asarray(tempos, dtype=np.float64)
    if arr.shape[1:] != (21, 3):
        raise ValueError(f"Formato invalido de pontos: {arr.shape}")
    if np.any(np.diff(ts) <= 0):
        raise ValueError("Timestamps devem ser estritamente crescentes.")
    # A janela [0, DURACAO_AMOSTRA] e a mesma na coleta e no reconhecimento.
    # Em cada extremo repetimos o ponto mais proximo disponivel.
    grade = np.linspace(ts[0], ts[-1], quantidade)
    flattened = arr.reshape(len(ts), -1)
    saida = np.stack([np.interp(grade, ts, flattened[:, i])
                     for i in range(flattened.shape[1])], axis=1)
    return saida.reshape(quantidade, 21, 3).astype(np.float32)


def vetor_caracteristicas(sequencia: np.ndarray) -> np.ndarray:
    """Retorna vetor invariavel a escala e translacao da pose, preservando movimento.

    Combina pose relativa ao punho (63 dados/quadro) + deslocamento do punho
    (2 dados/quadro). Isso ajuda a capturar sinais dinamicos como J e Z.
    O sinal faz uso de uma unica mao e deve ser treinado em orientacao semelhante.
    """
    seq = np.asarray(sequencia, dtype=np.float32)
    if seq.shape != (QUADROS, 21, 3):
        raise ValueError(f"Esperado {(QUADROS, 21, 3)}; recebido {seq.shape}")
    punho = seq[:, 0:1, :]
    escala = np.linalg.norm(seq[:, 9, :2] - seq[:, 0, :2], axis=1)
    escala = np.maximum(escala, 1e-4)
    # Evita variar escala por ruido quadro a quadro.
    escala_global = float(np.median(escala))
    pose = (seq - punho) / escala_global
    deslocamento = (seq[:, 0, :2] - seq[0, 0, :2]) / escala_global
    frame_features = np.concatenate(
        [pose.reshape(QUADROS, 63), deslocamento], axis=1
    )
    # Resume amplitude e percurso de movimento das pontas do indicador e minimo,
    # importantes para distinguir gestos de sinais estaticos.
    extras = []
    for dedo in (8, 20):
        xy = seq[:, dedo, :2]
        dist = np.linalg.norm(np.diff(xy, axis=0), axis=1)
        extras.extend([
            float(np.sum(dist) / escala_global),
            float((np.max(xy[:, 0]) - np.min(xy[:, 0])) / escala_global),
            float((np.max(xy[:, 1]) - np.min(xy[:, 1])) / escala_global),
        ])
    return np.concatenate((frame_features.ravel(), np.asarray(extras, dtype=np.float32)))


# Versao 2: modelo ESTATICO. Importante: nao misturar com features de movimento.
VERSAO_FEATURES_ESTATICAS = 2
LETRAS_ESTATICAS = tuple(letra for letra in LETRAS if letra not in "HJKXZ")


def vetor_pose_estatica(pontos: np.ndarray, lado: str | None = None,
                        mao_referencia: str = "esquerda") -> np.ndarray:
    """Extrai os mesmos atributos de uma foto/pose e de um quadro de webcam.

    - Ponto zero (punho) passa para a origem.
    - Escala pela distancia punho -> base do dedo medio.
    - Opcionalmente espelha a mao direita para o referencial esquerdo.
      O dataset publico nao informa lateralidade em cada .npz; assume-se que
      ele ja usa o referencial esquerdo adotado na origem LibraSign.
    - Adiciona distancias dos dedos e angulos das articulacoes.

    NOTA: espelhamento exige metadado confiavel de lateralidade. 'lado=None'
    nunca eh inferido a partir da posicao do polegar.
    """
    p = np.asarray(pontos, dtype=np.float32)
    if p.shape != (21, 3) or not np.isfinite(p).all():
        raise ValueError("A pose deve ter formato (21,3) e valores finitos.")
    p = p - p[0]
    escala = float(np.linalg.norm(p[9, :2]))
    if escala < 1e-4:
        raise ValueError("Pose invalida: distancia entre punho e base do dedo medio muito pequena.")
    p /= escala
    if mao_referencia not in ("esquerda", "nenhuma"):
        raise ValueError("mao_referencia deve ser 'esquerda' ou 'nenhuma'.")
    if mao_referencia == "esquerda" and lado in ("Right", "direita"):
        p[:, 0] *= -1.0
    # Angulos internos (cossenos) de 2 articulacoes por dedo.
    cadeias = ((1, 2, 3, 4), (5, 6, 7, 8), (9, 10, 11, 12),
               (13, 14, 15, 16), (17, 18, 19, 20))
    angulos = []
    for cadeia in cadeias:
        for j in (1, 2):
            a, b, c = cadeia[j-1], cadeia[j], cadeia[j+1]
            va, vc = p[a] - p[b], p[c] - p[b]
            den = max(float(np.linalg.norm(va) * np.linalg.norm(vc)), 1e-8)
            angulos.append(float(np.clip(np.dot(va, vc) / den, -1, 1)))
    pontas = (4, 8, 12, 16, 20)
    dist_punho = [float(np.linalg.norm(p[i])) for i in pontas]
    dist_vizinhas = [float(np.linalg.norm(p[a] - p[b]))
                      for a, b in zip(pontas[:-1], pontas[1:])]
    return np.concatenate((p.ravel(), np.asarray(angulos + dist_punho + dist_vizinhas,
                                                    dtype=np.float32))).astype(np.float32)
