"""Execute: python principal.py coletar | treinar | reconhecer | diagnosticar"""
from __future__ import annotations

import argparse
from collections import Counter, deque
from datetime import datetime
from pathlib import Path
import time
import uuid

import cv2
import joblib
import numpy as np

from libras_core import (
    DURACAO_AMOSTRA, LETRAS, MODELO_LIBRAS, PASTA_DADOS, QUADROS,
    VERSAO_FEATURES, RastreadorMao, abrir_camera, desenhar_mao,
    escrever, interpolar_sequencia, vetor_caracteristicas,
    LETRAS_ESTATICAS, VERSAO_FEATURES_ESTATICAS, vetor_pose_estatica,
    PASTA_MODELOS, ARESTAS,
)


def diagnosticar(indice: int) -> None:
    """Verifica camera + MediaPipe antes de coletar dados."""
    print("Abrindo a webcam; pressione Q ou ESC para sair.")
    camera = abrir_camera(indice)
    try:
        with RastreadorMao() as rastreador:
            while True:
                ok, imagem = camera.read()
                if not ok:
                    print("Falha ao ler a webcam.")
                    break
                imagem = cv2.flip(imagem, 1)
                pontos = rastreador.detectar(imagem)
                desenhar_mao(imagem, pontos)
                escrever(imagem, "Mao detectada" if pontos is not None else "Mostre sua mao", 34)
                if pontos is not None:
                    escrever(imagem, f"Lado (MediaPipe): {rastreador.ultimo_lado}", 68, tamanho=0.58)
                escrever(imagem, "Q: sair", 101, tamanho=0.55)
                cv2.imshow("Diagnostico - Libras", imagem)
                if cv2.waitKey(1) & 0xFF in (ord("q"), 27):
                    break
    finally:
        camera.release()
        cv2.destroyAllWindows()


def coletar(letra: str, quantidade: int, pessoa: str, indice: int) -> None:
    """Grava sequencias de pontos (NAO video/imagem) para uma letra."""
    letra = letra.upper()
    if letra not in LETRAS:
        raise ValueError("Escolha uma letra de A ate Z.")
    if quantidade < 1:
        raise ValueError("--quantidade deve ser pelo menos 1.")
    pasta = PASTA_DADOS / letra
    pasta.mkdir(parents=True, exist_ok=True)
    existentes = len(list(pasta.glob("*.npz")))
    print(f"Coletando letra {letra} para participante {pessoa}.")
    print("Aperte ESPACO para gravar cada exemplo. Repita os sinais de forma correta.")
    print("Siga uma referencia correta de Libras para ROTULAR cada coleta.")
    print("Sair: Q ou ESC.")
    camera = abrir_camera(indice)
    total_salvo = 0
    inicio = None
    pontos_clip: list[np.ndarray] = []
    tempos_clip: list[float] = []
    frames_clip = 0
    lados_clip: list[str] = []
    ultimo_aviso = ""
    aviso_ate = 0.0

    try:
        with RastreadorMao() as rastreador:
            while total_salvo < quantidade:
                ok, imagem = camera.read()
                if not ok:
                    print("Falha ao ler webcam.")
                    break
                imagem = cv2.flip(imagem, 1)
                pontos = rastreador.detectar(imagem)
                t = time.monotonic()
                desenhar_mao(imagem, pontos)
                escrever(imagem, f"Coleta: letra {letra} | pessoa: {pessoa}", 33)
                escrever(imagem, f"Novas: {total_salvo}/{quantidade} | existentes: {existentes}", 66, tamanho=0.57)

                if inicio is not None:
                    frames_clip += 1
                    if pontos is not None:
                        pontos_clip.append(pontos.copy())
                        tempos_clip.append(t - inicio)
                        if rastreador.ultimo_lado:
                            lados_clip.append(rastreador.ultimo_lado)
                    progresso = min((t - inicio) / DURACAO_AMOSTRA, 1.0)
                    escrever(imagem, f"GRAVANDO {int(progresso * 100)}%", 102, (0, 220, 255))
                    cv2.rectangle(imagem, (18, 117), (318, 134), (70, 70, 70), 2)
                    cv2.rectangle(imagem, (18, 117), (18 + int(300 * progresso), 134), (30, 190, 60), -1)

                    if t - inicio >= DURACAO_AMOSTRA:
                        # Quedas prolongadas de deteccao deixam um clip inutilizavel.
                        if len(pontos_clip) >= 7 and len(pontos_clip) / max(frames_clip, 1) >= 0.75:
                            seq = interpolar_sequencia(pontos_clip, tempos_clip)
                            nome = datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:8]
                            destino = pasta / f"{nome}.npz"
                            lado = Counter(lados_clip).most_common(1)[0][0] if lados_clip else ""
                            np.savez_compressed(destino, frames=seq, letra=letra,
                                                pessoa=pessoa, lado=lado, fonte="webcam")
                            total_salvo += 1
                            ultimo_aviso = "Exemplo salvo! Varie a distancia e inclinacao."
                            print(f"[{total_salvo}/{quantidade}] Salvo: {destino.relative_to(PASTA_DADOS.parent)}")
                        else:
                            ultimo_aviso = "Falhou: mantenha a mao visivel durante toda a coleta."
                            print(ultimo_aviso)
                        aviso_ate = t + 1.5
                        inicio = None
                        pontos_clip.clear()
                        tempos_clip.clear()
                        frames_clip = 0
                        lados_clip.clear()
                else:
                    escrever(imagem, "ESPACO: iniciar gravacao (1,25 s)", 102, (255, 240, 90), tamanho=0.65)
                    escrever(imagem, "Q: sair", 138, tamanho=0.56)

                if t < aviso_ate:
                    escrever(imagem, ultimo_aviso, imagem.shape[0] - 22, (0, 255, 255), tamanho=0.58)
                elif pontos is None:
                    escrever(imagem, "Mostre uma mao a camera", imagem.shape[0] - 22,
                             (50, 150, 255), tamanho=0.6)

                cv2.imshow("Coleta de Libras", imagem)
                tecla = cv2.waitKey(1) & 0xFF
                if tecla in (ord("q"), 27):
                    break
                if tecla == 32 and inicio is None:
                    if pontos is None:
                        ultimo_aviso = "Mostre sua mao antes de iniciar."
                        aviso_ate = t + 1.5
                    else:
                        inicio = t
                        pontos_clip = [pontos.copy()]
                        tempos_clip = [0.0]
                        frames_clip = 1
                        lados_clip = [rastreador.ultimo_lado] if rastreador.ultimo_lado else []
    finally:
        camera.release()
        cv2.destroyAllWindows()
    print(f"Coleta encerrada: {total_salvo} novas amostras da letra {letra}.")


# ------------------------------------------------------------
# Etapa 2: classificador de POSES ESTATICAS, compativel com CSV
# do LibraSign e com exemplos coletados pela webcam.
# ------------------------------------------------------------
MODELO_ESTATICO = PASTA_MODELOS / "classificador_libras_estatico.joblib"
PASTA_RESULTADOS = Path(__file__).resolve().parent / "resultados"


def _texto_npz(arq, nome: str, default: str = "") -> str:
    if nome not in arq:
        return default
    return str(np.asarray(arq[nome]).item())


def carregar_dados_estaticos(mao_referencia: str = "esquerda"):
    """Usa a pose mediana: um vetor igual para dados publicos e webcam.

    Nao inclui movimento nem tenta aprender H/J/K/X/Z a partir de poses isoladas.
    """
    xs, ys, pessoas, fontes = [], [], [], []
    contagem = Counter()
    contagem_fontes = Counter()
    arquivos = sorted(PASTA_DADOS.glob("*/*.npz"))
    for caminho in arquivos:
        letra = caminho.parent.name.upper()
        if letra not in LETRAS_ESTATICAS:
            continue
        try:
            with np.load(caminho, allow_pickle=False) as arq:
                seq = np.asarray(arq["frames"], dtype=np.float32)
                rotulo = _texto_npz(arq, "letra", letra)
                pessoa = _texto_npz(arq, "pessoa", "desconhecido")
                fonte = _texto_npz(arq, "fonte", "")
                lado = _texto_npz(arq, "lado", "")
            if rotulo != letra or seq.ndim != 3 or seq.shape[1:] != (21, 3):
                raise ValueError("rotulo ou formato divergente")
            if not np.isfinite(seq).all():
                raise ValueError("pose com NaN ou infinito")
            if seq.shape[0] < 1:
                raise ValueError("sequencia vazia")
            # Webcam: mediana reduz tremor. Dataset publico: 18 quadros identicos.
            pose = np.median(seq, axis=0)
            atributos = vetor_pose_estatica(pose, lado=lado,
                                            mao_referencia=mao_referencia)
            publica = (pessoa == "dataset_publico" or
                       "librasign" in fonte.lower() or
                       caminho.name.startswith("librasign_kaggle_"))
            grupo = "publico" if publica else "webcam"
            xs.append(atributos)
            ys.append(letra)
            pessoas.append(pessoa)
            fontes.append(grupo)
            contagem[letra] += 1
            contagem_fontes[(letra, grupo)] += 1
        except (ValueError, KeyError, OSError, IndexError) as erro:
            print(f"[IGNORADO] {caminho.name}: {erro}")
    if not xs:
        raise RuntimeError("Nao encontrei amostras. Importe o LibraSign antes de treinar.")
    return (np.asarray(xs, np.float32), np.asarray(ys), np.asarray(pessoas),
            np.asarray(fontes), contagem, contagem_fontes)


def pesos_por_origem(y: np.ndarray, fontes: np.ndarray,
                     fracao_real: float = 0.50) -> np.ndarray:
    """Equilibra letras e reserva peso para webcam, se a classe tiver webcam.

    Impede que 150 exemplos publicos dominem 20 exemplos reais da mesma letra.
    Pesos usados SOMENTE no ajuste do modelo, nao na avaliacao.
    """
    pesos = np.zeros(len(y), dtype=np.float64)
    for letra in np.unique(y):
        publico = np.where((y == letra) & (fontes == "publico"))[0]
        webcam = np.where((y == letra) & (fontes == "webcam"))[0]
        if len(publico) and len(webcam):
            pesos[publico] = (1 - fracao_real) / len(publico)
            pesos[webcam] = fracao_real / len(webcam)
        elif len(publico):
            pesos[publico] = 1 / len(publico)
        elif len(webcam):
            pesos[webcam] = 1 / len(webcam)
    return pesos


def escolher_divisao(y: np.ndarray, pessoas: np.ndarray, fontes: np.ndarray):
    """Testa em amostras reais nunca usadas no treino sempre que possivel."""
    from sklearn.model_selection import train_test_split

    ind_publico = np.flatnonzero(fontes == "publico")
    ind_webcam = np.flatnonzero(fontes == "webcam")
    if len(ind_webcam):
        participantes = sorted(set(pessoas[ind_webcam]))
        if len(participantes) >= 2:
            # Reserva um participante inteiro que possua mais exemplos.
            escolhido = max(participantes, key=lambda p: np.count_nonzero(
                (fontes == "webcam") & (pessoas == p)))
            teste = np.flatnonzero((fontes == "webcam") & (pessoas == escolhido))
            treino = np.setdiff1d(np.arange(len(y)), teste)
            vistos = set(y[treino])
            teste = teste[np.isin(y[teste], list(vistos))]
            if len(teste) >= 3 and len(set(y[treino])) >= 2:
                return treino, teste, f"WEBcam: participante '{escolhido}' excluido do treino"
        if len(ind_publico) and len(set(y[ind_publico])) >= 2:
            # Diagnostico de transferencia ANTES de adicionar exemplos reais.
            teste = ind_webcam[np.isin(y[ind_webcam], np.unique(y[ind_publico]))]
            if len(teste) >= 3:
                return ind_publico, teste, "PUBLICO -> WEBCAM: todas as amostras reais reservadas para teste"
    if min(Counter(y).values()) >= 2:
        train, test = train_test_split(np.arange(len(y)), test_size=0.2,
                                       random_state=42, stratify=y)
        return train, test, "ALEATORIA: resultado otimista; nao mede generalizacao para webcam"
    raise RuntimeError("Faltam exemplos por letra para separar treino e teste.")


def novo_modelo():
    from sklearn.ensemble import RandomForestClassifier
    return RandomForestClassifier(
        n_estimators=250, min_samples_leaf=2, n_jobs=-1, random_state=42,
        max_features="sqrt",
    )


def treinar(mao_referencia: str = "esquerda", fracao_real: float = 0.5) -> None:
    from sklearn.metrics import accuracy_score, classification_report, f1_score, confusion_matrix

    x, y, pessoas, fontes, contagem, por_fonte = carregar_dados_estaticos(mao_referencia)
    print("\nAMOSTRAS POR LETRA (publicas / webcam):")
    for letra in sorted(contagem):
        print(f"  {letra}: {por_fonte[(letra, 'publico')]} / {por_fonte[(letra, 'webcam')]}")
    print(f"Total: {len(y)} | {len(contagem)}/21 letras estaticas")
    if len(contagem) < 2 or min(contagem.values()) < 3:
        raise RuntimeError("Necessario ter pelo menos 2 letras com 3 amostras cada.")

    i_treino, i_teste, modo = escolher_divisao(y, pessoas, fontes)
    avaliador = novo_modelo()
    avaliador.fit(x[i_treino], y[i_treino],
                  sample_weight=pesos_por_origem(y[i_treino], fontes[i_treino], fracao_real))
    pred = avaliador.predict(x[i_teste])
    ac = accuracy_score(y[i_teste], pred)
    f1 = f1_score(y[i_teste], pred, average="macro", zero_division=0)
    print("\n=== AVALIACAO (antes do treino final) ===")
    print("Estrategia:", modo)
    print(f"Amostras de teste: {len(i_teste)} | Classes presentes no teste: {len(np.unique(y[i_teste]))}")
    print(f"Acuracia: {ac:.1%} | F1-macro: {f1:.3f}")
    print(classification_report(y[i_teste], pred, zero_division=0))
    if len(np.unique(y[i_teste])) < len(np.unique(y)):
        print("ATENCAO: nem todas as letras estao representadas no teste; F1 cobre apenas o subconjunto avaliado.")
    if modo.startswith("ALEATORIA"):
        print("ATENCAO: os dados publicos repetem poses; este numero nao e qualidade da webcam.")

    PASTA_RESULTADOS.mkdir(parents=True, exist_ok=True)
    classes = np.unique(y)
    cm = confusion_matrix(y[i_teste], pred, labels=classes)
    arq_cm = PASTA_RESULTADOS / "matriz_confusao_v2.csv"
    with arq_cm.open("w", encoding="utf-8") as f:
        f.write("real/predita," + ",".join(classes) + "\n")
        for letra, linha in zip(classes, cm):
            f.write(letra + "," + ",".join(map(str, linha)) + "\n")

    # Modelo final passa a usar o dataset inteiro, inclusive webcam, DEPOIS de avaliar.
    modelo = novo_modelo()
    modelo.fit(x, y, sample_weight=pesos_por_origem(y, fontes, fracao_real))
    MODELO_ESTATICO.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({
        "modelo": modelo, "versao_features_estaticas": VERSAO_FEATURES_ESTATICAS,
        "mao_referencia": mao_referencia, "classes": classes.tolist(),
        "contagem_fontes": {f"{k[0]}_{k[1]}": v for k, v in por_fonte.items()},
        "resultado_teste": {"estrategia": modo, "acuracia": float(ac),
                           "f1_macro": float(f1), "numero_teste": len(i_teste)},
    }, MODELO_ESTATICO)
    print(f"\nModelo salvo: {MODELO_ESTATICO}")
    print(f"Matriz de confusao: {arq_cm}")
    print("Execute: python principal.py reconhecer")
    print("NOTA: H, J, K, X e Z continuam fora do modelo estatico.")


def _desenhar_painel(frame: np.ndarray, top: list[tuple[str, float]],
                     prevista: str, estavel: bool, progresso: float,
                     texto: str, mensagem: str) -> None:
    altura, largura = frame.shape[:2]
    painel = frame.copy()
    cv2.rectangle(painel, (0, 0), (360, 258), (25, 28, 35), -1)
    cv2.addWeighted(painel, 0.78, frame, 0.22, 0, frame)
    escrever(frame, "LIBRAS | letras estaticas", 30, tamanho=0.67, x=14)
    escrever(frame, "Previsoes (pontuacoes, nao certezas):", 58, tamanho=0.46, x=14)
    if top:
        for i, (letra, valor) in enumerate(top[:3]):
            y = 88 + 43 * i
            escrever(frame, f"{i+1}. {letra}  {valor:4.0%}", y, tamanho=0.59, x=14,
                     cor=(110, 245, 130) if i == 0 else (240, 240, 240))
            cv2.rectangle(frame, (145, y-16), (341, y-1), (95, 95, 95), -1)
            cv2.rectangle(frame, (145, y-16), (145 + int(196 * valor), y-1),
                          (90, 190, 85) if i == 0 else (180, 160, 75), -1)
    else:
        escrever(frame, mensagem, 95, tamanho=0.65, x=14)
    est = f"ESTAVEL: {prevista}" if estavel else f"Atual: {prevista}"
    escrever(frame, est, 226, (0, 225, 255) if estavel else (250, 250, 250), 0.7, x=14)
    cv2.rectangle(frame, (14, 240), (340, 249), (70, 70, 70), -1)
    cv2.rectangle(frame, (14, 240), (14 + int(326 * progresso), 249), (0, 225, 255), -1)
    cv2.rectangle(frame, (0, altura-83), (largura, altura), (20, 22, 26), -1)
    escrever(frame, "Texto: " + texto[-48:], altura-52, tamanho=0.65)
    escrever(frame, "ESPACO: incluir | S: foto | BACKSPACE: apagar | C: limpar | Q: sair",
             altura-20, tamanho=0.46)


def reconhecer(indice: int, limite: float = 0.44, margem: float = 0.07,
               estabilidade: float = 0.6) -> None:
    """Classifica poses de 1 quadro; suaviza as previsoes, nao os exemplos."""
    if not MODELO_ESTATICO.exists():
        raise RuntimeError("Modelo estatico ausente. Execute 'python principal.py treinar' primeiro.")
    pacote = joblib.load(MODELO_ESTATICO)
    if pacote.get("versao_features_estaticas") != VERSAO_FEATURES_ESTATICAS:
        raise RuntimeError("Modelo antigo/incompativel. Treine novamente com a v2.")
    modelo = pacote["modelo"]
    mao_ref = pacote["mao_referencia"]
    print("Letras disponiveis:", ", ".join(modelo.classes_))
    print("Pontuacoes sao votos do Random Forest, NAO confianca estatistica calibrada.")
    print("Q/ESC sair | ESPACO inserir letra ESTAVEL | S salvar tela | C limpar")

    camera = abrir_camera(indice)
    poses: deque[np.ndarray] = deque(maxlen=5)
    ema: np.ndarray | None = None
    top: list[tuple[str, float]] = []
    candidata = ""
    inicio_candidata = 0.0
    confirmada = ""
    progresso = 0.0
    texto = ""
    contador = 0
    try:
        with RastreadorMao() as rastreador:
            while True:
                ok, imagem = camera.read()
                if not ok:
                    print("Falha ao ler quadro da webcam.")
                    break
                imagem = cv2.flip(imagem, 1)
                pontos = rastreador.detectar(imagem)
                desenhar_mao(imagem, pontos)
                agora = time.monotonic()
                contador += 1
                mensagem = "Coloque uma mao na camera"
                if pontos is None:
                    ema, top, candidata, confirmada = None, [], "", ""
                    poses.clear()
                    progresso = 0.0
                else:
                    poses.append(pontos.copy())
                    if len(poses) >= 3 and contador % 2 == 0:
                        pose = np.median(np.stack(poses), axis=0)
                        try:
                            feat = vetor_pose_estatica(pose, rastreador.ultimo_lado,
                                                       mao_referencia=mao_ref)
                            prob = modelo.predict_proba(feat[None, :])[0]
                            ema = prob if ema is None else 0.33*prob + 0.67*ema
                            ordem = np.argsort(ema)[::-1]
                            top = [(str(modelo.classes_[j]), float(ema[j])) for j in ordem[:3]]
                            maior = float(ema[ordem[0]])
                            segunda = float(ema[ordem[1]]) if len(ordem) > 1 else 0.0
                            nova = str(modelo.classes_[ordem[0]]) if (
                                maior >= limite and maior - segunda >= margem) else ""
                            if nova != candidata:
                                candidata, inicio_candidata = nova, agora
                            if candidata:
                                progresso = min(1.0, (agora - inicio_candidata) / estabilidade)
                                confirmada = candidata if progresso >= 1.0 else ""
                            else:
                                confirmada = ""
                                progresso = 0.0
                        except ValueError:
                            ema, top, candidata, confirmada = None, [], "", ""
                            progresso = 0.0
                            mensagem = "Posicao nao detectada com qualidade"

                prevista = top[0][0] if top else "--"
                _desenhar_painel(imagem, top, prevista, bool(confirmada),
                                progresso, texto, mensagem)
                cv2.imshow("Libras - modo estatico V2", imagem)
                tecla = cv2.waitKey(1) & 0xFF
                if tecla in (ord("q"), 27):
                    break
                elif tecla == 32:
                    if confirmada:
                        texto += confirmada
                        print("Texto:", texto)
                    else:
                        print("Aguarde ate aparecer ESTAVEL.")
                elif tecla in (8, 127):
                    texto = texto[:-1]
                elif tecla == ord("c"):
                    texto = ""
                elif tecla == ord("s"):
                    PASTA_RESULTADOS.mkdir(exist_ok=True)
                    nome = PASTA_RESULTADOS / f"captura_{datetime.now():%Y%m%d_%H%M%S}.png"
                    png_ok, png_buf = cv2.imencode(".png", imagem)
                    if png_ok:
                        png_buf.tofile(str(nome))  # suporte a caminhos com acentos no Windows
                        print("Captura salva:", nome)
    finally:
        camera.release()
        cv2.destroyAllWindows()
    print("Texto final:", texto if texto else "(vazio)")


def _amostra_padrao(letra: str, fonte: str) -> tuple[np.ndarray, str] | None:
    arquivos = sorted((PASTA_DADOS / letra).glob("*.npz"))
    if fonte == "publico":
        arquivos = [p for p in arquivos if p.name.startswith("librasign_kaggle_")]
    elif fonte == "webcam":
        arquivos = [p for p in arquivos if not p.name.startswith("librasign_kaggle_")]
    if not arquivos:
        return None
    caminho = arquivos[len(arquivos)//2]  # exemplo deterministico, nao necessariamente tipico
    with np.load(caminho, allow_pickle=False) as arq:
        pose = np.median(np.asarray(arq["frames"], np.float32), axis=0)
    return pose, caminho.name


def visualizar(fonte: str = "publico") -> None:
    """Gera uma grade com os ESQUELETOS; dataset nao contem fotos originais."""
    ncol = 5
    largura, altura = 230, 235
    letras = LETRAS_ESTATICAS
    nlin = (len(letras) + ncol - 1) // ncol
    imagem = np.full((nlin*altura, ncol*largura, 3), 247, dtype=np.uint8)
    exibidas = 0
    for i, letra in enumerate(letras):
        x0, y0 = (i%ncol)*largura, (i//ncol)*altura
        cv2.rectangle(imagem, (x0+3, y0+3), (x0+largura-4,y0+altura-4), (215,215,215), 1)
        escrever(imagem, letra, y0+30, cor=(25,25,25), tamanho=0.92, x=x0+16)
        amostra = _amostra_padrao(letra, fonte)
        if amostra is None:
            escrever(imagem, "sem dados", y0+125, cor=(70,70,70), tamanho=0.53, x=x0+18)
            continue
        pts, arquivo = amostra
        xy = pts[:, :2]
        ext = np.ptp(xy, axis=0)
        maior = max(float(ext.max()), 1e-6)
        origem = np.mean(xy, axis=0)
        tela = (xy - origem) / maior * 155 + [x0 + largura/2, y0 + 125]
        coordenadas = [(int(xx),int(yy)) for xx, yy in tela]
        for a, b in ARESTAS:
            cv2.line(imagem, coordenadas[a], coordenadas[b], (55,145,55), 2, cv2.LINE_AA)
        for xx, yy in coordenadas:
            cv2.circle(imagem, (xx,yy), 4, (45,65,205), -1, cv2.LINE_AA)
        exibidas += 1
    PASTA_RESULTADOS.mkdir(parents=True, exist_ok=True)
    nome = PASTA_RESULTADOS / f"landmarks_{fonte}.png"
    png_ok, png_buf = cv2.imencode(".png", imagem)
    if not png_ok:
        raise RuntimeError(f"Nao foi possivel codificar imagem {nome}")
    png_buf.tofile(str(nome))  # caminho Unicode no Windows
    print(f"Imagem com {exibidas} poses criada em: {nome}")
    print("ATENCAO: sao esqueletos dos landmarks, nao as fotografias originais.")


def resumo() -> None:
    _, _, pessoas, fontes, contagem, por_fonte = carregar_dados_estaticos()
    print("\nLetra | Publico | Webcam")
    for letra in sorted(contagem):
        print(f" {letra:>3}  |  {por_fonte[(letra, 'publico')]:>5}  |  {por_fonte[(letra, 'webcam')]:>5}")
    print("Participantes reais:", ", ".join(sorted(set(pessoas[fontes == "webcam"]))) or "nenhum")
    print("Letras fora do modo estatico: H, J, K, X, Z")


def main() -> None:
    parser = argparse.ArgumentParser(description="Libras (poses estaticas) com MediaPipe")
    sub = parser.add_subparsers(dest="acao", required=True)
    sub.add_parser("resumo", help="Contar dados publicos e da webcam por letra")
    diag = sub.add_parser("diagnosticar", help="Testar a camera e o MediaPipe")
    diag.add_argument("--camera", type=int, default=0)
    col = sub.add_parser("coletar", help="Adicionar exemplos reais da webcam")
    col.add_argument("--letra", required=True, type=str)
    col.add_argument("--quantidade", type=int, default=30)
    col.add_argument("--pessoa", type=str, default="p1")
    col.add_argument("--camera", type=int, default=0)
    treino = sub.add_parser("treinar", help="Treinar o modelo de poses estaticas")
    treino.add_argument("--mao-referencia", choices=("esquerda", "nenhuma"),
                        default="esquerda", help="Padronizacao de lateralidade")
    treino.add_argument("--peso-real", type=float, default=0.5,
                        help="Fracao do peso dedicada a exemplos webcam por letra (0 a 1)")
    rec = sub.add_parser("reconhecer", help="Abrir a webcam com top-3 e estabilidade")
    rec.add_argument("--camera", type=int, default=0)
    rec.add_argument("--limite", type=float, default=0.44)
    rec.add_argument("--margem", type=float, default=0.07)
    rec.add_argument("--estabilidade", type=float, default=0.6)
    viz = sub.add_parser("visualizar", help="Gerar imagem com exemplos de landmarks")
    viz.add_argument("--fonte", choices=("publico", "webcam", "qualquer"), default="publico")
    args = parser.parse_args()
    try:
        if args.acao == "diagnosticar":
            diagnosticar(args.camera)
        elif args.acao == "coletar":
            if args.letra.upper() not in LETRAS_ESTATICAS:
                raise ValueError("V2 estatica so coleta A B C D E F G I L M N O P Q R S T U V W Y")
            coletar(args.letra, args.quantidade, args.pessoa, args.camera)
        elif args.acao == "treinar":
            if not 0 <= args.peso_real <= 1:
                parser.error("--peso-real deve ficar entre 0 e 1")
            treinar(args.mao_referencia, args.peso_real)
        elif args.acao == "reconhecer":
            if not 0 < args.limite <= 1 or not 0 <= args.margem <= 1 or args.estabilidade <= 0:
                parser.error("Limite/margem/estabilidade invalidos")
            reconhecer(args.camera, args.limite, args.margem, args.estabilidade)
        elif args.acao == "visualizar":
            visualizar(args.fonte)
        elif args.acao == "resumo":
            resumo()
    except (RuntimeError, ValueError, OSError) as erro:
        parser.exit(1, f"ERRO: {erro}\n")


if __name__ == "__main__":
    main()
