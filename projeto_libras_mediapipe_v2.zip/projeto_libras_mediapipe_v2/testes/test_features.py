import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
from libras_core import QUADROS, interpolar_sequencia, vetor_caracteristicas


def fake_hand(n=QUADROS):
    rng = np.random.default_rng(3)
    v = np.array([0.3, 0.4, 0.0], dtype=np.float32) + rng.random((n, 21, 3), dtype=np.float32) * 0.09
    v[:, 9, :2] += 0.2  # escala da palma > 0
    return v


def test_features_dimensionality():
    x = vetor_caracteristicas(fake_hand())
    assert x.shape == (QUADROS * 65 + 6,)
    assert np.isfinite(x).all()


def test_features_translation_and_scale_invariance():
    a = fake_hand()
    b = a.copy() * 2.0
    b[:, :, 0] += 0.11
    b[:, :, 1] -= 0.09
    # Como os x,y,z estao em mesma escala multiplicativa, featurizacao coincide.
    np.testing.assert_allclose(vetor_caracteristicas(a), vetor_caracteristicas(b), rtol=1e-5, atol=1e-5)


def test_interpolate_to_fixed_frames():
    raw = fake_hand(11)
    ts = np.linspace(0, 1.25, 11)
    out = interpolar_sequencia(list(raw), list(ts))
    assert out.shape == (QUADROS, 21, 3)
    np.testing.assert_allclose(out[0], raw[0], atol=1e-6)
    np.testing.assert_allclose(out[-1], raw[-1], atol=1e-6)
